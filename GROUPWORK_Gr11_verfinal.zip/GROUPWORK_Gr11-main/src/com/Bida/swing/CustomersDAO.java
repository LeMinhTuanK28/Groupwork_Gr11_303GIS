package com.Bida.swing;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;

public class CustomersDAO {

    private Map<String, Customers> customersMap = new HashMap<>();
    List<Customers> ls = new ArrayList<>();

    public int add(Customers cus) {
        if (customersMap.containsKey(cus.getId())) {
            return -1; // ID đã tồn tại
        } else {
            customersMap.put(cus.getId(), cus);
            ls.add(cus);
            return 1; // Thêm thành công
        }
    }

    public List<Customers> getAllCustomer() {
        return ls;
    }

    public int delCustomer(String de) {
        Iterator<Customers> iterator = ls.iterator();
        while (iterator.hasNext()) {
            Customers cus = iterator.next();
            if (cus.getId().equalsIgnoreCase(de)) {
                iterator.remove(); // Sử dụng Iterator để xóa
                return 1;
            }
        }
        return -1;
    }

    public Optional<Customers> getCusById(String id) {
        for (Customers cus : ls) {
            if (cus.getId().equalsIgnoreCase(id)) {
                return Optional.of(cus);
            }
        }
        return Optional.empty();
    }
}
