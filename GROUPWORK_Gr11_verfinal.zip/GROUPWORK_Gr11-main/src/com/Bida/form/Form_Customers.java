/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.Bida.form;

import com.Bida.swing.Customers;
import com.Bida.swing.CustomersDAO;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Form_Customers extends javax.swing.JPanel {

    CustomersDAO dao = new CustomersDAO();
    String strImage = null;

    public Form_Customers() {
        initComponents();
    }

    public class MyTableModel extends DefaultTableModel {

        @Override
        public boolean isCellEditable(int row, int column) {
            return isEditMode;
        }
    }

    public void fillTableDele() {
        DefaultTableModel model = (DefaultTableModel) dataCUSTOMER.getModel();
        Vector<Vector> tableData = model.getDataVector();

        // Remove the deleted customer's data from the CSV file
        try (BufferedReader br = new BufferedReader(new FileReader("D:\\303 GIS\\GROUPWORK_Gr11-main\\GROUPWORK_Gr11-main\\src\\CSV\\ShowInfoCus.txt"))) {
            List<Customers> customerList = new ArrayList<>();
            String line;
            while ((line = br.readLine()) != null) {
                String[] columns = line.split(",");
                if (!columns[0].equals(txtID.getText().trim())) {
                    Customers cus = new Customers(columns[0], columns[1], columns[2], columns[3].equals("MALE"), columns[4]);
                    customerList.add(cus);
                }
            }

            // Write the updated data back to the CSV file
            try (BufferedWriter bw = new BufferedWriter(new FileWriter("D:\\303 GIS\\GROUPWORK_Gr11-main\\GROUPWORK_Gr11-main\\src\\CSV\\ShowInfoCus.txt"))) {
                for (Customers cus : customerList) {
                    bw.write(cus.getId() + "," + cus.getName() + "," + cus.getPhone() + "," + (cus.isGender() ? "MALE" : "FEMALE") + "," + cus.getImage());
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Update the JTable
        model.setRowCount(0);
        for (Customers cus : dao.getAllCustomer()) {
            Object rowData[] = new Object[5];
            rowData[0] = cus.getId();
            rowData[1] = cus.getName();
            rowData[2] = cus.getPhone();
            rowData[3] = cus.isGender() ? "MALE" : "FEMALE";
            rowData[4] = cus.getImage();
            model.addRow(rowData);
        }
//        model.setRowCount(0);
//        fillTable();
//        model.fireTableDataChanged();
    }

    public void fillTable() {
        DefaultTableModel model = (DefaultTableModel) dataCUSTOMER.getModel();
        List<Customers> customerList = dao.getAllCustomer();
        if (customerList.isEmpty()) {
            System.out.println("Không tồn tại thông tin khách hàng!");
            return;
        }
        model.setRowCount(0);
        for (Customers cus : dao.getAllCustomer()) {
            Object rowData[] = new Object[5];
            rowData[0] = cus.getId();
            rowData[1] = cus.getName();
            rowData[2] = cus.getPhone();
            rowData[3] = cus.isGender() ? "MALE" : "FEMALE";
            rowData[4] = cus.getImage();
            model.addRow(rowData);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        javax.swing.JScrollPane jScrollPane1 = new javax.swing.JScrollPane();
        dataCUSTOMER = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txtPhone = new javax.swing.JTextField();
        btADD = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        ibImage = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        gdMale = new javax.swing.JRadioButton();
        btEDIT = new javax.swing.JButton();
        gdFemale = new javax.swing.JRadioButton();
        btDELETE = new javax.swing.JButton();
        txtName = new javax.swing.JTextField();
        btSAVE = new javax.swing.JButton();
        txtID = new javax.swing.JTextField();

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Data Customers:");

        dataCUSTOMER.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "PHONE", "GENDER", "IMAGE"
            }
        ));
        dataCUSTOMER.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataCUSTOMERMouseClicked(evt);
            }
        });
        dataCUSTOMER.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                dataCUSTOMERInputMethodTextChanged(evt);
            }
        });
        jScrollPane1.setViewportView(dataCUSTOMER);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ID:");

        txtPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneActionPerformed(evt);
            }
        });

        btADD.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btADD.setText("RESET");
        btADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btADDActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Fullname:");

        ibImage.setBackground(new java.awt.Color(204, 255, 255));
        ibImage.setText("Image");
        ibImage.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ibImage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ibImageMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Phone:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Gender:");

        buttonGroup1.add(gdMale);
        gdMale.setSelected(true);
        gdMale.setText("Male");
        gdMale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gdMaleActionPerformed(evt);
            }
        });

        btEDIT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btEDIT.setText("EDIT");
        btEDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEDITActionPerformed(evt);
            }
        });

        buttonGroup1.add(gdFemale);
        gdFemale.setText("Female");
        gdFemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gdFemaleActionPerformed(evt);
            }
        });

        btDELETE.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btDELETE.setText("DELETE");
        btDELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDELETEActionPerformed(evt);
            }
        });

        btSAVE.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btSAVE.setText("SAVE");
        btSAVE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSAVEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(btADD, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(gdMale))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(gdFemale, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btEDIT, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btDELETE, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btSAVE, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                        .addComponent(ibImage, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(gdMale)
                            .addComponent(gdFemale))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btADD, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btEDIT, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btDELETE, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btSAVE, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(ibImage, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    public void reset() {
        txtID.setText("");
        txtName.setText("");
        txtPhone.setText("");

        gdMale.setSelected(true);

        ibImage.setText("Empty Image");
        ibImage.setIcon(null);

        strImage = null;
    }
    private void txtPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneActionPerformed
    }//GEN-LAST:event_txtPhoneActionPerformed

    public boolean isValidPhoneNumber(String phoneNumber) {
        // Kiểm tra xem SĐT nhập vào rỗng hay không;
        if (phoneNumber.isEmpty()) {
            return false;
        }

        // Kiểm tra xem SĐT nhập vào chứa kí tự chữ hay kí tự đặc biệt không;
        if (!phoneNumber.matches("\\d+")) {
            return false;
        }

        // Kiểm tra độ dài tối đa của SĐT (<= 11);
        return phoneNumber.length() <= 11;
    }

    public boolean isValidName(String fullName) {
        if (fullName.isEmpty()) {
            return false;
        }

        return fullName.matches("[a-zA-Z\\s]+");
    }

    public boolean isValidID(String ID) {

        if (ID.isEmpty()) {
            return false;
        }

        return ID.matches("[a-zA-Z0-9]+");
    }

    public boolean checkID(String id) {
        List<Customers> customerList = dao.getAllCustomer();
        for (Customers customer : customerList) {
            if (customer.getId().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }
    private void btADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btADDActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_btADDActionPerformed

    private void gdMaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gdMaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gdMaleActionPerformed

    private void gdFemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gdFemaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gdFemaleActionPerformed

    private void ibImageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ibImageMouseClicked
        // TODO add your handling code here:
        try {
            JFileChooser jf = new JFileChooser();
            jf.showOpenDialog(null);
            File file = jf.getSelectedFile();
            Image img = ImageIO.read(file);
            strImage = file.getName();
            ibImage.setText("");
            int width = ibImage.getWidth();
            int height = ibImage.getHeight();
            ibImage.setIcon(new ImageIcon(img.getScaledInstance(width, height, 0)));
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }//GEN-LAST:event_ibImageMouseClicked
    public Customers getModel() throws ParseException {
        Customers cus = new Customers();
        cus.setId(txtID.getText());
        cus.setName(txtName.getText());
        cus.setPhone(txtPhone.getText());
        boolean gd = false;
        if (gdMale.isSelected()) {
            gd = true;
        }
        cus.setGender(gd);
        if (strImage == null) {
            cus.setImage("NO AVATAR");
        } else {
            cus.setImage(strImage);
        }
        return cus;
    }
    private void btSAVEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSAVEActionPerformed
        if (validateForm()) {
            try {
                // Lấy thông tin khách hàng từ form
                Customers cus = getModel();
                if (saveCustomerDatabase(cus)) {
                    if (writeCustomerToCSV(cus)) {
                        // Hiển thị thông báo thành công
                        JOptionPane.showMessageDialog(this, "Lưu thành công!");
                        refreshTableData();
                        resetForm();
                    } else {
                        JOptionPane.showMessageDialog(this, "Ghi vào file CSV thất bại!");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Lưu thất bại!");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_btSAVEActionPerformed

    private boolean saveCustomerDatabase(Customers customer) {
        try {
            return dao.add(customer) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean writeCustomerToCSV(Customers customer) {
        String filePath = "D:\\303 GIS\\GROUPWORK_Gr11-main\\GROUPWORK_Gr11-main\\src\\CSV\\ShowInfoCus.txt";
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath, true))) {
            String gender = customer.isGender() ? "Male" : "Female";
            pw.println(customer.getId() + "," + customer.getName() + "," + customer.getPhone() + "," + gender + "," + customer.getImage());
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void refreshTableData() {
        fillTable();
        dataCUSTOMER.revalidate();
        dataCUSTOMER.repaint();
    }

    private void resetForm() {
        reset();
    }

    public void setModel(Customers cus) {
        txtID.setText(cus.getId());
        txtName.setText(cus.getName());
        if (cus.isGender()) {
            gdMale.isSelected();
        } else {
            gdFemale.isSelected();
        }
        // load hinh anh;
        ibImage.setText("");
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("com/Bida/icon/" + cus.getImage()));
        Image img = imgIcon.getImage();
        img.getScaledInstance(ibImage.getWidth(), ibImage.getY(), 0);
    }
    private void dataCUSTOMERMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataCUSTOMERMouseClicked
        int id = dataCUSTOMER.rowAtPoint(evt.getPoint());
        String cusid = dataCUSTOMER.getValueAt(id, 0).toString();
        Optional<Customers> cus = dao.getCusById(cusid);
    }//GEN-LAST:event_dataCUSTOMERMouseClicked

    boolean isEditMode = true;
    private void btEDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEDITActionPerformed
        isEditMode = !isEditMode;
        if (isEditMode) {
            JOptionPane.showMessageDialog(this, "Đã BẬT chế độ CHỈNH SỬA. Bây giờ bạn KHÔNG THỂ sửa thông tin khách hàng!");
        } else {
            JOptionPane.showMessageDialog(this, "Đã TẮT chế độ CHỈNH SỬA. Bây giờ bạn CÓ THỂ sửa thông tin khách hàng!");
        }
        dataCUSTOMER.setEnabled(isEditMode);
        dataCUSTOMER.repaint();
    }//GEN-LAST:event_btEDITActionPerformed

    private void btDELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDELETEActionPerformed
        // TODO add your handling code here:
        String cusID = txtID.getText().trim();

        if (cusID.isEmpty()) {
            JOptionPane.showConfirmDialog(this, "Vui lòng nhập ID của khách hàng cần xóa!");
            txtID.requestFocus();
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa thông tin của khách hàng này ? [ID:" + cusID + "]", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.delCustomer(cusID) > 0) {
                JOptionPane.showMessageDialog(this, "Xóa thông tin khách hàng thành công! [ID:" + cusID + "]");
                fillTableDele();
                reset();
            } else {
                JOptionPane.showConfirmDialog(this, "Không tìm thấy khách hàng với ID: " + cusID + ". Xóa không thành công!");
            }
        }
    }//GEN-LAST:event_btDELETEActionPerformed

    private void updateFile() {
        try {
            List<Customers> customersList = dao.getAllCustomer();

            // Tạo mới file để ghi đè lại dữ liệu
            PrintWriter pw = new PrintWriter(new FileWriter("D:\\303 GIS\\GROUPWORK_Gr11-main\\GROUPWORK_Gr11-main\\src\\CSV\\ShowInfoCus.txt"));

            // Ghi dữ liệu từ danh sách khách hàng vào file
            for (Customers cus : customersList) {
                pw.println(cus.getId() + "," + cus.getName() + "," + cus.getPhone() + "," + (cus.isGender() ? "Male" : "Female") + "," + cus.getImage());
            }

            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean validateForm() {
        // Lấy giá trị từ các trường nhập liệu
        String id = txtID.getText();
        String fullName = txtName.getText();
        String phoneNumber = txtPhone.getText();

        // Kiểm tra nếu trường ID, Name hoặc Phone bị rỗng
        if (id.isEmpty() || fullName.isEmpty() || phoneNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn chưa nhập đủ thông tin!");
            return false; // Không hợp lệ
        }
        if (!isValidID(id)) {
            JOptionPane.showMessageDialog(this, "ID của khách hàng không hợp lệ, vui lòng nhập lại!");
            return false;
        }
        if (!isValidName(fullName)) {
            JOptionPane.showMessageDialog(this, "Tên của khách hàng không hợp lệ, vui lòng nhập lại!");
            return false;
        }
        if (!isValidPhoneNumber(phoneNumber)) {
            JOptionPane.showMessageDialog(this, "Số điện thoại đã nhập không hợp lệ, vui lòng nhập lại!");
            return false;
        }
        if (checkID(id)) {
            JOptionPane.showMessageDialog(this, "ID của khách hàng đã tồn tại, vui lòng nhập lại!");
            return false;
        }
        return true;
    }

    public DefaultTableModel getdataCUSTOMER() {
        return (DefaultTableModel) dataCUSTOMER.getModel();
    }

    private void dataCUSTOMERInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_dataCUSTOMERInputMethodTextChanged

    }//GEN-LAST:event_dataCUSTOMERInputMethodTextChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btADD;
    private javax.swing.JButton btDELETE;
    private javax.swing.JButton btEDIT;
    private javax.swing.JButton btSAVE;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTable dataCUSTOMER;
    private javax.swing.JRadioButton gdFemale;
    private javax.swing.JRadioButton gdMale;
    private javax.swing.JLabel ibImage;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPhone;
    // End of variables declaration//GEN-END:variables

}
