package com.Bida.model;
public enum StatusType_Boss {
    QUITJOB, DISMISS, WORKING, DAYOFF
}
