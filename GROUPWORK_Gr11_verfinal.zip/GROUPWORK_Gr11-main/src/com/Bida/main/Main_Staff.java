package com.Bida.main;

import LoginAndSignup.JFrame_LOGIN;
import com.Bida.event.EventMenuSelected;
import com.Bida.form.*;
import com.Bida.form.Form_PoolTables;
import com.Bida.form.Form_Customers;
import java.awt.Color;
import javax.swing.JComponent;
import javax.swing.JOptionPane;

public class Main_Staff extends javax.swing.JFrame {

    public Main_Staff() {
        initComponents();
        setBackground(new Color(0, 0, 0, 0));
        menu1.initMoving(Main_Staff.this);
        menu1.addEventMenuSelected(new EventMenuSelected() {
            @Override
            public void selected(int index) {
                if (index == 3) {
                    setForm(new Form_Home_Staff());
                } else if (index == 4) {
                    setForm(new Form_PoolTables());
                } else if (index == 5) {
                    setForm(new Form_Customers());
                } else if (index == 9) {
                    setForm(new Form_Account());
                } else if (index == 10) {
                    setForm(new Form_More());
                } else if (index == 11) {
                    int a = JOptionPane.showConfirmDialog(null, "Do you really want to Logout?", "Select Options:", JOptionPane.YES_NO_OPTION);
                    if (a == 0) {
                        JFrame_LOGIN JL = new JFrame_LOGIN();
                        JL.setVisible(true);
                        JL.pack();
                        JL.setLocationRelativeTo(null);
                        dispose();
                    }
                }
            }
        });
        setForm(new Form_Home_Staff());
    }

//    private Form_Customers formCustomer;
    private void setForm(JComponent com) {
        mainPanel2.removeAll();
//        if (com instanceof Form_Customers) {
//            formCustomer = (Form_Customers) com;
//        }
        mainPanel2.add(com);
        mainPanel2.repaint();
        mainPanel2.revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBorder1 = new com.Bida.swing.PanelBorder();
        menu1 = new com.Bida.component.Menu_Staff();
        header1 = new com.Bida.component.Header();
        mainPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));

        mainPanel2.setBackground(new java.awt.Color(204, 204, 204));
        mainPanel2.setOpaque(false);
        mainPanel2.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(header1, javax.swing.GroupLayout.DEFAULT_SIZE, 995, Short.MAX_VALUE)
                    .addComponent(mainPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, 638, Short.MAX_VALUE)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addComponent(header1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(mainPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing

//            DefaultTableModel model = formCustomer.getdataCUSTOMER();
//            Vector<Vector> tableData = model.getDataVector();
//            try {
//                FileOutputStream file = new FileOutputStream("D:\\303 GIS\\GROUPWORK_Gr11-main\\GROUPWORK_Gr11-main\\src\\CSV\\ShowInfoCus.txt");
//                ObjectOutputStream output = new ObjectOutputStream(file);
//                output.writeObject(tableData);
//                output.close();
//                file.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }

    }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
//        try {
//            FileInputStream file = new FileInputStream("D:\\303 GIS\\GROUPWORK_Gr11-main\\GROUPWORK_Gr11-main\\src\\CSV\\ShowInfoCus.txt");
//            ObjectInputStream input = new ObjectInputStream(file);
//            Vector<Vector> tableData = (Vector<Vector>) input.readObject();
//
//            input.close();
//            file.close();
//
//            DefaultTableModel model = formCustomer.getdataCUSTOMER();
//            for (int i = 0; i < tableData.size(); i++) {
//                Vector row = tableData.get(i);
//                model.addRow(new Object[]{row.get(0), row.get(1), row.get(2), row.get(3), row.get(4)});
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }//GEN-LAST:event_formWindowOpened

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrame_LOGIN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.Bida.component.Header header1;
    private javax.swing.JPanel mainPanel2;
    private com.Bida.component.Menu_Staff menu1;
    private com.Bida.swing.PanelBorder panelBorder1;
    // End of variables declaration//GEN-END:variables
}
